public class ejemploConcat{
	public static void main(String args[]){
		String frase1 = "Esto va al principio";
		String frase2 = " y esto va después de lo anterior...";
		System.out.println(frase1.concat(frase2));
	}
}