public class ejemploPrint{
	public static void main(String[] args){
		System.out.println("Hola a todos");
		System.out.print("Este texto queda debajo por el println");
		System.out.print("  y este queda al lado por el uso de print");
	}
}