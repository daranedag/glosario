public class ejemploLowerUpper{
	public static void main(String args[]){
		String frase = "eSTa eS uNa FRaSe Que TieNe LaS VoCaLeS eN MiNuSCuLaS";
		System.out.println("Asi se ve con el metodo toLowerCase(): "+ frase.toLowerCase());
		System.out.println("Asi se ve con el metodo toUpperCase(): "+ frase.toUpperCase());		
	}
}